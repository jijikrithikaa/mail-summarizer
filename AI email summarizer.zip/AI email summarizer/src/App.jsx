import React, { useState, useEffect, useRef } from 'react';
import {
    Mail, Send, Sparkles, Clipboard, Mic, MicOff, Check, AlertCircle,
    BarChart3, Globe, User as UserIcon, ChevronRight,
    FileText, Briefcase, Zap, Activity, Wand2, History as HistoryIcon, TrendingUp
} from 'lucide-react';

const API_BASE_URL = 'http://127.0.0.1:8000';

function App() {
    const [userName, setUserName] = useState(localStorage.getItem('aura_user') || 'Elite Agent');
    const [isEditingName, setIsEditingName] = useState(false);
    const [loading, setLoading] = useState(false);
    const [isListening, setIsListening] = useState(false);
    const [copied, setCopied] = useState(false);
    const [error, setError] = useState(null);
    const [backendStatus, setBackendStatus] = useState('Checking...');
    const [formData, setFormData] = useState({
        context: '',
        tone: 'Formal',
        key_points: '',
        language: 'English'
    });
    const [suggestedTone, setSuggestedTone] = useState(null);
    const [result, setResult] = useState(null);
    const [sentiment, setSentiment] = useState({ score: 50, intensity: 'Neutral', label: 'Aura Level' });
    const [templates, setTemplates] = useState({});
    const [history, setHistory] = useState([]);
    const [insights, setInsights] = useState(null);
    const [showInsights, setShowInsights] = useState(false);
    const [showExport, setShowExport] = useState(false);

    const recognitionRef = useRef(null);
    const suggestTimeoutRef = useRef(null);
    const analyzeTimeoutRef = useRef(null);

    useEffect(() => {
        checkBackend();
        fetchTemplates();
        fetchHistory();
        fetchInsights();
        // ... existence of webkitSpeechRecognition logic ...
    }, []);

    useEffect(() => {
        if (formData.context.length > 10) {
            if (suggestTimeoutRef.current) clearTimeout(suggestTimeoutRef.current);
            suggestTimeoutRef.current = setTimeout(fetchToneSuggestion, 800);
        }
    }, [formData.context]);

    const fetchToneSuggestion = async () => {
        try {
            const res = await fetch(`${API_BASE_URL}/suggest-tone`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ context: formData.context })
            });
            if (res.ok) setSuggestedTone(await res.json());
        } catch (e) { console.error("Tone suggest failed"); }
    };

    const fetchRealTimeScoring = async (text) => {
        try {
            const res = await fetch(`${API_BASE_URL}/analyze`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text, tone: formData.tone })
            });
            if (res.ok) setSentiment(await res.json());
        } catch (e) { console.error("Real-time scoring failed"); }
    };

    const handleBodyChange = (e) => {
        const newBody = e.target.value;
        setResult(prev => ({ ...prev, body: newBody }));

        if (analyzeTimeoutRef.current) clearTimeout(analyzeTimeoutRef.current);
        analyzeTimeoutRef.current = setTimeout(() => fetchRealTimeScoring(newBody), 500);
    };

    const checkBackend = async () => {
        try {
            const res = await fetch(`${API_BASE_URL}/templates`);
            if (res.ok) setBackendStatus('Online');
            else setBackendStatus('Issue Detected');
        } catch (e) { setBackendStatus('Offline'); }
    };

    const fetchTemplates = async () => {
        try {
            const res = await fetch(`${API_BASE_URL}/templates`);
            if (res.ok) setTemplates(await res.json());
        } catch (e) { console.error("Could not fetch templates"); }
    };

    const fetchHistory = async () => {
        try {
            const res = await fetch(`${API_BASE_URL}/history`);
            if (res.ok) setHistory(await res.json());
        } catch (e) { console.error("History fetch failed"); }
    };

    const fetchInsights = async () => {
        try {
            const res = await fetch(`${API_BASE_URL}/insights`);
            if (res.ok) setInsights(await res.json());
        } catch (e) { console.error("Insights fetch failed"); }
    };

    const handleNameChange = (e) => {
        const val = e.target.value;
        setUserName(val);
        localStorage.setItem('aura_user', val);
    };

    const toggleListening = () => {
        if (isListening) recognitionRef.current?.stop();
        else {
            setError(null);
            try { recognitionRef.current?.start(); setIsListening(true); }
            catch (e) { setError("Microphone access denied."); }
        }
    };

    const generateEmail = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);
        try {
            const response = await fetch(`${API_BASE_URL}/generate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            if (!response.ok) throw new Error('Engine Calibration Failed. Please restart the backend.');

            const data = await response.json();
            setResult(data);
            if (data.sentiment) setSentiment(data.sentiment);
            fetchHistory();
            fetchInsights();
        } catch (err) {
            setError(err.message === 'Failed to fetch' ? 'Sync Error: Please ensure the Backend is running on port 8000 (0.0.0.0:8000).' : err.message);
        } finally {
            setLoading(false);
        }
    };

    const applyTemplate = (name) => {
        const t = templates[name];
        setFormData({ ...formData, context: t.context, key_points: t.points, tone: t.tone });
    };

    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="app-container animate-fade-in">
            <aside className="sidebar">
                <div className="sidebar-header">
                    <TrendingUp size={20} />
                    <span>Communication Hub</span>
                </div>
                <button className="insights-trigger" onClick={() => setShowInsights(true)}>
                    <Sparkles size={16} />
                    <span>View Aura Insights</span>
                </button>

                <div className="sidebar-header mt-4">
                    <HistoryIcon size={20} />
                    <span>Recent History</span>
                </div>
                <div className="history-list">
                    {history.map(item => (
                        <button key={item.id} className="history-item" onClick={() => setResult(item.result_json)}>
                            <div className="item-meta">
                                <span className="item-tone">{item.tone}</span>
                                <span className="item-date">{new Date(item.timestamp).toLocaleDateString()}</span>
                            </div>
                            <span className="item-context">{item.context.substring(0, 30)}...</span>
                        </button>
                    ))}
                </div>

                <div className="sidebar-header mt-4">
                    <Briefcase size={20} />
                    <span>Scenarios</span>
                </div>
                <div className="template-list">
                    {Object.keys(templates).map(name => (
                        <button key={name} className="template-item" onClick={() => applyTemplate(name)}>
                            <span>{name}</span>
                            <ChevronRight size={14} />
                        </button>
                    ))}
                    {Object.keys(templates).length === 0 && (
                        <div className="no-templates">Library Ready (Manual Input Active)</div>
                    )}
                </div>
                <div className="user-profile">
                    <div className="user-avatar"><UserIcon size={20} /></div>
                    <div className="user-info">
                        {isEditingName ? (
                            <input
                                autoFocus
                                className="name-edit"
                                value={userName}
                                onChange={handleNameChange}
                                onBlur={() => setIsEditingName(false)}
                                onKeyDown={e => e.key === 'Enter' && setIsEditingName(false)}
                            />
                        ) : (
                            <span className="user-name" onClick={() => setIsEditingName(true)}>{userName} ✎</span>
                        )}
                        <span className="user-status">
                            {backendStatus === 'Online' ? <><span className="status-dot online"></span> Live</> : <><span className="status-dot offline"></span> {backendStatus}</>}
                        </span>
                    </div>
                </div>
            </aside>

            <main className="main-content">
                <div className="glass-card">
                    <div className="brand-header">
                        <div className="logo-container">
                            <Sparkles className="logo-icon floating" size={32} />
                            <div className="logo-glow"></div>
                        </div>
                        <div>
                            <h1>Aura Mail</h1>
                            <div className="lang-row">
                                <Globe size={14} />
                                <select
                                    value={formData.language}
                                    onChange={e => setFormData({ ...formData, language: e.target.value })}
                                    className="lang-select"
                                >
                                    <option>English</option>
                                    <option>Hindi</option>
                                    <option>Spanish</option>
                                    <option>French</option>
                                    <option>German</option>
                                    <option>Japanese</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <form onSubmit={generateEmail}>
                        <div className="form-group">
                            <div className="label-row">
                                <label>Interaction Context</label>
                                <button type="button" className={`mic-btn ${isListening ? 'listening' : ''}`} onClick={toggleListening}>
                                    {isListening ? <MicOff size={18} /> : <Mic size={18} />}
                                </button>
                            </div>
                            <textarea
                                placeholder="Describe your objective..."
                                value={formData.context}
                                onChange={(e) => setFormData({ ...formData, context: e.target.value })}
                                required
                            />
                        </div>

                        <div className="form-grid">
                            <div className="form-group">
                                <div className="label-row">
                                    <label>Target Aura</label>
                                    {suggestedTone && suggestedTone.tone !== formData.tone && (
                                        <button
                                            type="button"
                                            className="suggest-chip animate-fade-in"
                                            onClick={() => setFormData({ ...formData, tone: suggestedTone.tone })}
                                            title={suggestedTone.reason}
                                        >
                                            <Wand2 size={12} />
                                            <span>Suggest: {suggestedTone.tone}</span>
                                        </button>
                                    )}
                                </div>
                                <select value={formData.tone} onChange={(e) => setFormData({ ...formData, tone: e.target.value })}>
                                    <option>Formal</option>
                                    <option>Friendly</option>
                                    <option>Assertive</option>
                                    <option>Diplomatic</option>
                                    <option>Persuasive</option>
                                </select>
                                {suggestedTone && suggestedTone.tone === formData.tone && (
                                    <div className="tone-rationale animate-fade-in">
                                        <Sparkles size={10} /> {suggestedTone.reason}
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="form-group">
                            <label>Key Deliverables</label>
                            <textarea
                                className="small-textarea"
                                placeholder="List goals (comma separated)..."
                                value={formData.key_points}
                                onChange={(e) => setFormData({ ...formData, key_points: e.target.value })}
                                required
                            />
                        </div>

                        {error && <div className="error-message"><AlertCircle size={16} />{error}</div>}

                        <button type="submit" className="generate-btn" disabled={loading}>
                            {loading ? <span className="loader-container"><span className="loader"></span><span>Synchronizing...</span></span> : <><Zap size={20} /><span>Generate High-Impact Aura</span></>}
                        </button>
                    </form>
                </div>

                <div className="glass-card result-card">
                    {error && <div className="error-message"><AlertCircle size={16} />{error}</div>}

                    {result ? (
                        <div className="result-section animate-fade-in">
                            <div className="aura-visualization">
                                <div className="aura-stat">
                                    <Activity size={20} color="#8338ec" />
                                    <span>{sentiment.label}: {Math.round(sentiment.score)}%</span>
                                </div>
                                <div className="aura-bar-bg"><div className="aura-bar-fill" style={{ width: `${sentiment.score}%` }}></div></div>

                                {sentiment.dimensions && (
                                    <div className="dimensions-grid">
                                        {Object.entries(sentiment.dimensions).map(([dim, val]) => (
                                            <div key={dim} className="dim-item">
                                                <span className="dim-label">{dim}</span>
                                                <div className="dim-track"><div className="dim-fill" style={{ width: `${val}%` }}></div></div>
                                                <span className="dim-val">{Math.round(val)}%</span>
                                            </div>
                                        ))}
                                    </div>
                                )}
                                <span className="aura-intensity">{sentiment.intensity} Calibration</span>
                            </div>

                            {result.doubts && result.doubts.length > 0 && (
                                <div className="doubts-block animate-fade-in">
                                    <div className="block-header">
                                        <h3>AI Doubt Assistant</h3>
                                        <Sparkles size={14} className="logo-icon" />
                                    </div>
                                    <div className="doubts-list">
                                        {result.doubts.map((d, i) => (
                                            <div key={i} className="doubt-item" onClick={() => setFormData({ ...formData, context: formData.context + " " })}>
                                                <AlertCircle size={14} />
                                                <span>{d}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            <div className="result-block">
                                <div className="block-header">
                                    <h3>Aura Subjects</h3>
                                    <button className="icon-btn" onClick={() => setShowExport(!showExport)} title="Doc Mode"><FileText size={16} /></button>
                                </div>
                                <div className="subject-list">
                                    {result.subjects.map((s, i) => (
                                        <div key={i} className="subject-item">
                                            <span>{s}</span>
                                            <button className="copy-small" onClick={() => copyToClipboard(s)}><Clipboard size={14} /></button>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="result-block">
                                <div className="block-header">
                                    <h3>Final Intelligence Output</h3>
                                    <button className={`copy-btn ${copied ? 'success' : ''}`} onClick={() => copyToClipboard(result.body)}>
                                        {copied ? <Check size={16} /> : <Clipboard size={16} />}
                                        {copied ? 'Copied' : 'Copy Output'}
                                    </button>
                                </div>
                                <div className={`email-body-container ${showExport ? 'doc-mode' : ''}`}>
                                    {showExport ? (
                                        <>
                                            <div className="doc-header">
                                                <div className="doc-branding">AURA INTEL | {userName.toUpperCase()}</div>
                                                <div className="doc-date">{new Date().toLocaleDateString()}</div>
                                            </div>
                                            <div className="email-body">{result.body}</div>
                                            <div className="doc-footer">Aura intelligence Engine v2.0 | High Speed Access</div>
                                        </>
                                    ) : (
                                        <textarea
                                            className="email-body-editor"
                                            value={result.body}
                                            onChange={handleBodyChange}
                                            spellCheck="false"
                                        />
                                    )}
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className="empty-state">
                            <div className="empty-icon-container">
                                <Mail className="floating" size={80} />
                                <div className="aura-circle"></div>
                            </div>
                            <h3>Intelligence Network Ready</h3>
                            <p>Enter context to synthesize professional aura communication.</p>
                        </div>
                    )}
                </div>
            </main>

            {showInsights && insights && (
                <div className="insights-overlay animate-fade-in" onClick={() => setShowInsights(false)}>
                    <div className="insights-panel glass-card" onClick={e => e.stopPropagation()}>
                        <div className="panel-header">
                            <div>
                                <TrendingUp size={24} color="#00ffaa" />
                                <h2>Communication Mastery Dashboard</h2>
                            </div>
                            <button className="close-btn" onClick={() => setShowInsights(false)}>×</button>
                        </div>

                        <div className="insights-grid">
                            <div className="stat-card">
                                <span className="stat-label">Total Synthesis</span>
                                <span className="stat-value">{insights.total_generated}</span>
                                <span className="stat-sub">High-Impact Emails Created</span>
                            </div>
                            <div className="stat-card">
                                <span className="stat-label">Efficiency Gain</span>
                                <span className="stat-value">{insights.efficiency}</span>
                                <span className="stat-sub">Aura Processing Time Saved</span>
                            </div>
                            <div className="stat-card">
                                <span className="stat-label">Avg. Aura Strength</span>
                                <span className="stat-value">{Math.round(insights.avg_aura)}%</span>
                                <span className="stat-sub">Professional Communication Power</span>
                            </div>
                        </div>

                        <div className="chart-section">
                            <h3>Tone Dominance</h3>
                            <div className="tone-bars">
                                {Object.entries(insights.tone_distribution).map(([tone, count]) => (
                                    <div key={tone} className="tone-bar-item">
                                        <div className="bar-label">
                                            <span>{tone}</span>
                                            <span>{count}</span>
                                        </div>
                                        <div className="bar-track">
                                            <div
                                                className="bar-fill"
                                                style={{ width: `${(count / insights.total_generated) * 100}%` }}
                                            ></div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="chart-section">
                            <h3>Communication Dimensions (Avg)</h3>
                            <div className="dim-bars-large">
                                {Object.entries(insights.dimensions_avg).map(([dim, val]) => (
                                    <div key={dim} className="dim-bar-item">
                                        <div className="bar-label">
                                            <span>{dim}</span>
                                            <span>{Math.round(val)}%</span>
                                        </div>
                                        <div className="bar-track">
                                            <div className="bar-fill dim" style={{ width: `${val}%` }}></div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

export default App;
