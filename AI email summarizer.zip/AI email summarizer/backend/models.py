from sqlalchemy import Column, Integer, String, ForeignKey, JSON, DateTime
from sqlalchemy.orm import relationship
from database import Base
import datetime

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    email = Column(String, unique=True, index=True)
    password_hash = Column(String)
    emails = relationship("Email", back_populates="owner")

class Email(Base):
    __tablename__ = "emails"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    context = Column(String)
    tone = Column(String)
    key_points = Column(String)
    result_json = Column(JSON)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    owner = relationship("User", back_populates="emails")
