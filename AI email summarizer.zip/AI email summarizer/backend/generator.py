import os

# Internal Intelligence Logic and OpenAI Mock
# In a production environment, this would call os.getenv("OPENAI_API_KEY")

def analyze_sentiment(text, target_tone="Formal"):
    # Expanded Multi-dimensional Analysis
    # Analyzes Impact, Clarity, Professionalism, and Tone Match
    high_impact = ["strategic", "roi", "alignment", "growth", "efficiency", "urgent", "imperative", "proposition", "deliverable"]
    low_professionalism = ["maybe", "stuff", "thing", "problem", "trying", "think", "sort of", "whatever"]
    
    # Tone Specific Keywords for Tone Match
    tone_keywords = {
        "Formal": ["pertains", "align", "objectives", "synchronization", "perspective", "respectfully"],
        "Friendly": ["productive", "collaborate", "thanks", "best", "touch base", "coordinate"],
        "Assertive": ["imperative", "immediately", "resolution", "accountability", "required", "definitive"],
        "Diplomatic": ["considerations", "balanced", "effectively", "appreciate", "context", "navigating"],
        "Persuasive": ["opportunity", "exceptional", "results", "value", "proposal", "confident"]
    }

    impact_v = sum(1 for word in high_impact if word.lower() in text.lower())
    low_v = sum(1 for word in low_professionalism if word.lower() in text.lower())
    
    # Calculate Base Scores
    clarity = 75 + (len(text.split()) / 10) - (low_v * 12)
    professionalism = 82 + (impact_v * 4) - (low_v * 15)
    
    # Calculate Tone Match
    match_keywords = tone_keywords.get(target_tone, [])
    match_count = sum(1 for word in match_keywords if word.lower() in text.lower())
    tone_match = 60 + (match_count * 15)

    return {
        "score": min(100, max(0, (clarity + professionalism + tone_match) / 3)),
        "dimensions": {
            "Clarity": min(100, max(0, clarity)),
            "Professionalism": min(100, max(0, professionalism)),
            "Tone Match": min(100, max(0, tone_match))
        },
        "intensity": "High" if impact_v > 3 else "Balanced",
        "label": "Aura Strength"
    }

def extract_doubts(context, points):
    doubts = []
    text = (context + " " + points).lower()
    
    if "[name]" in text or "someone" in text or "recipient" not in text and "to:" not in text:
        doubts.append("Who is the specific recipient? (e.g. 'To Mr. Sharma')")
    if "deadline" not in text and "by" not in text and "date" not in text:
        doubts.append("Is there a specific deadline for this request?")
    if len(points.split(',')) < 2:
        doubts.append("Could you add one more key objective for better impact?")
    if len(context) < 15:
        doubts.append("The situation is a bit brief. Any more context on the 'Why'?")
        
    return doubts

def suggest_tone(context):
    c = context.lower()
    if any(x in c for x in ["complaint", "issue", "delay", "broken", "failed", "unacceptable"]):
        return {"tone": "Diplomatic", "reason": "Conflict detected. A diplomatic approach maintains professional relations while addressing the issue."}
    if any(x in c for x in ["meeting", "follow-up", "intro", "greet", "update"]):
        return {"tone": "Friendly", "reason": "Relationship building context. A friendly tone encourages open collaboration."}
    if any(x in c for x in ["urgent", "immediately", "deadline", "important", "now"]):
        return {"tone": "Assertive", "reason": "Time-sensitive context. Assertiveness ensures clarity and action."}
    if any(x in c for x in ["request", "proposal", "feedback", "advice"]):
        return {"tone": "Persuasive", "reason": "Influence detected. A persuasive tone helps in alignment and buy-in."}
    
    return {"tone": "Formal", "reason": "Defaulting to professional standards for business communication."}

def calculate_insights(emails):
    if not emails:
        return {
            "total_generated": 0,
            "avg_aura": 0,
            "tone_distribution": {},
            "dimensions_avg": {"Clarity": 0, "Professionalism": 0, "Tone Match": 0},
            "efficiency": "0h Saved"
        }
    
    tone_counts = {}
    total_aura = 0
    dim_sums = {"Clarity": 0, "Professionalism": 0, "Tone Match": 0}
    
    for email in emails:
        # Handle both dict result_json and object
        data = email.result_json if hasattr(email, 'result_json') else email.get('result_json', {})
        tone = email.tone if hasattr(email, 'tone') else email.get('tone', 'Formal')
        
        tone_counts[tone] = tone_counts.get(tone, 0) + 1
        
        sent = data.get('sentiment', {})
        total_aura += sent.get('score', 0)
        
        dims = sent.get('dimensions', {})
        for k in dim_sums:
            dim_sums[k] += dims.get(k, 0)
            
    count = len(emails)
    return {
        "total_generated": count,
        "avg_aura": total_aura / count,
        "tone_distribution": tone_counts,
        "dimensions_avg": {k: v / count for k, v in dim_sums.items()},
        "efficiency": f"{round(count * 12 / 60, 1)}h Saved",
        "top_tone": max(tone_counts, key=tone_counts.get) if tone_counts else "None"
    }

TEMPLATES = {
    "Resignation": {
        "context": "Resigning from current position as [Job Title]",
        "points": "Standard notice period, gratitude for opportunities, offer to help with transition",
        "tone": "Formal"
    },
    "Promotion Request": {
        "context": "Requesting a performance review and promotion to [Job Title]",
        "points": "Key achievements in last 6 months, increased responsibilities, market rate alignment",
        "tone": "Assertive"
    },
    "Meeting Follow-up": {
        "context": "Brief summary and action items from today's meeting",
        "points": "Action items assigned to [Name], next steps, deadline for feedback",
        "tone": "Friendly"
    },
    "Project Delay": {
        "context": "Informing stakeholders about a 1-week delay in Project X",
        "points": "Reason for delay (technical debt), revised timeline, mitigation steps taken",
        "tone": "Diplomatic"
    }
}

def translate_content(content, target_lang):
    # Simulated Multi-language Engine
    translations = {
        "Hindi": {
            "Strategic Discussion": "रणनीतिक चर्चा",
            "Dear": "प्रिय",
            "Respectfully": "सादर",
            "Hi": "नमस्ते",
            "Best regards": "शुभकामनाएं",
            "Regards": "सादर प्रणाम",
            "Action Required": "कार्रवाई आवश्यक है"
        },
        "Spanish": {
            "Strategic Discussion": "Discusión Estratégica",
            "Dear": "Estimado/a",
            "Respectfully": "Respetuosamente",
            "Hi": "Hola",
            "Best regards": "Saludos cordiales",
            "Regards": "Saludos",
            "Action Required": "Acción Requerida"
        },
        "German": {
            "Strategic Discussion": "Strategische Diskussion",
            "Dear": "Sehr geehrte/r",
            "Respectfully": "Hochachtungsvoll",
            "Hi": "Hallo",
            "Best regards": "Herzliche Grüße",
            "Regards": "Grüße",
            "Action Required": "Handlung Erforderlich"
        },
        "Japanese": {
            "Strategic Discussion": "戦略的ディスカッション",
            "Dear": "拝啓",
            "Respectfully": "敬具",
            "Hi": "こんにちは",
            "Best regards": "よろしくお願いいたします",
            "Regards": "敬具",
            "Action Required": "対応が必要です"
        }
    }
    
    if target_lang not in translations:
        return content
        
    translated = content
    for eng, trans in translations[target_lang].items():
        translated = translated.replace(eng, trans)
    return translated

def generate_structured_email(context, tone, points, language="English"):
    # This function simulates the high-impact AI generation
    keyPointsArray = [p.strip() for p in points.split(',')]
    
    result = {}
    
    # Selection logic based on 'Context-Aware Business Intelligence'
    if tone == "Formal":
        result = {
            "subjects": [
                f"Strategic Alignment: {context[:30]}",
                f"Executive Memo: Addressing {keyPointsArray[0]}"
            ],
            "body": f"Dear [Recipient Name],\n\nThis communication pertains to {context}. Following a thorough internal review, it is requested that we align on the following critical objectives:\n\n" + "\n".join([f"• {p}" for p in keyPointsArray]) + f"\n\nEnsuring synchronization on these points will be vital to our ongoing strategic success. I look forward to your perspective on these matters.\n\nRespectfully,\n\n[Your Name]",
            "preview": "A formalized executive communication designed to align stakeholders on project-critical milestones.",
            "styleExplanation": "The writing employs a sophisticated, objective register to underscore professional accountability and strategic alignment while mitigating communication risk."
        }
    elif tone == "Friendly":
        result = {
            "subjects": [
                f"Update: {context[:20]}",
                f"Checking in on {keyPointsArray[0]}"
            ],
            "body": f"Hi [Name],\n\nI hope your week is off to a productive start! I'm reaching out to coordinate on {context}.\n\nSpecifically, I'd like to touch base on a few areas:\n" + "\n".join([f"- {p}" for p in keyPointsArray]) + f"\n\nI value your input on these and would love to hear your thoughts when you have a moment.\n\nBest regards,\n\n[Your Name]",
            "preview": "An approachable yet professional update aimed at fostering cross-functional collaboration and clarity.",
            "styleExplanation": "This approach utilizes inclusive language and a courteous rhythm to strengthen professional relationships while maintaining structural clarity."
        }
    elif tone == "Persuasive":
        result = {
            "subjects": [
                f"Opportunity: {context[:25]}",
                f"Proposal for {keyPointsArray[0]}"
            ],
            "body": f"Dear [Name],\n\nI trust you're doing well. I've been analyzing our approach to {context} and believe there's a significant opportunity for us to drive value together. By focusing on the following key areas, we can achieve exceptional results:\n\n" + "\n".join([f"• {p}" for p in keyPointsArray]) + f"\n\nI'm confident this path will yield strong returns. I'd love to schedule a brief call to discuss the potential ROI further.\n\nBest,\n\n[Your Name]",
            "preview": "A strategically framed proposal designed to emphasize value proposition and stakeholder buy-in.",
            "styleExplanation": "The logic focuses on benefit-oriented language and logical progression to drive consensus while adhering to professional decorum."
        }
    elif tone == "Diplomatic":
        result = {
            "subjects": [
                f"Regarding {context[:25]}",
                f"Coordination: {keyPointsArray[0]}"
            ],
            "body": f"Dear [Name],\n\nI'm writing to share some context regarding our progress on {context}. To ensure we navigate the next phase effectively, it would be beneficial to keep the following considerations in mind:\n\n" + "\n".join([f"• {p}" for p in keyPointsArray]) + f"\n\nI appreciate your collaboration as we work through these details. Please let me know if you have any reflections on the above.\n\nBest regards,\n\n[Your Name]",
            "preview": "A balanced communication designed to navigate sensitive topics while maintaining professional relationships.",
            "styleExplanation": "The style uses neutral, inclusive phrasing to convey situational awareness and invite collaboration without assigning direct blame."
        }
    else:
        # Default assertive/neutral
        result = {
            "subjects": [
                f"Action Required: {context[:25]}",
                f"Resolution Needed: {keyPointsArray[0]}"
            ],
            "body": f"To [Recipient Name],\n\nI am writing to ensure we achieve a definitive resolution regarding {context}. To maintain our current trajectory, it is imperative that the following items are addressed immediately:\n\n" + "\n".join([f"• {p}" for p in keyPointsArray]) + f"\n\nClear accountability on these points will allow us to proceed without further operational impact. I look forward to receiving your confirmation.\n\nRegards,\n\n[Your Name]",
            "preview": "A direct, high-impact communication focused on immediate problem-solving and operational accountability.",
            "styleExplanation": "The style uses authoritative, declarative phrasing to convey urgency and clear expectations without descending into inappropriate or aggressive language."
        }
    
    # Analyze sentiment & Doubts
    sentiment = analyze_sentiment(result["body"], tone)
    result["sentiment"] = sentiment
    result["doubts"] = extract_doubts(context, points)
    
    # Apply Translation if needed
    if language != "English":
        result["body"] = translate_content(result["body"], language)
        result["subjects"] = [translate_content(s, language) for s in result["subjects"]]
        result["preview"] = translate_content(result["preview"], language)
    
    return result
