from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import database, auth, generator, models
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI(title="Aura Mail - Business Intelligence Engine")

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Models for request/response
class UserCreate(BaseModel):
    name: str
    email: str
    password: str

class UserLogin(BaseModel):
    email: str
    password: str

class EmailRequest(BaseModel):
    context: str
    tone: str
    key_points: str
    language: Optional[str] = "English"

class ToneSuggestRequest(BaseModel):
    context: str

class AnalyzeRequest(BaseModel):
    text: str
    tone: str

@app.get("/templates")
def get_templates():
    return generator.TEMPLATES

@app.post("/suggest-tone")
def suggest_tone(request: ToneSuggestRequest):
    return generator.suggest_tone(request.context)

@app.post("/analyze")
def analyze_text(request: AnalyzeRequest):
    return generator.analyze_sentiment(request.text, request.tone)

# ... rest remains same ...
models.Base.metadata.create_all(bind=database.engine)

@app.post("/register")
def register(user: UserCreate, db: Session = Depends(database.get_db)):
    db_user = db.query(models.User).filter(models.User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    hashed_password = auth.get_password_hash(user.password)
    new_user = models.User(name=user.name, email=user.email, password_hash=hashed_password)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return {"message": "User created successfully"}

@app.post("/login")
def login(user: UserLogin, db: Session = Depends(database.get_db)):
    db_user = db.query(models.User).filter(models.User.email == user.email).first()
    if not db_user or not auth.verify_password(user.password, db_user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    access_token = auth.create_access_token(data={"sub": db_user.email})
    return {"access_token": access_token, "token_type": "bearer", "user": {"name": db_user.name, "email": db_user.email}}

@app.post("/generate")
def generate_email(request: EmailRequest, user_name: Optional[str] = None, current_user: Optional[models.User] = Depends(auth.get_current_user_optional), db: Session = Depends(database.get_db)):
    # Call AI logic
    email_data = generator.generate_structured_email(request.context, request.tone, request.key_points, request.language)
    
    # Save to history
    user_id = current_user.id if current_user else None
    # For simulation/fast access, we allow saving history by user_name in a special way if needed
    # But to keep it simple and within the current schema, we'll favor the user_id if present
    
    new_email = models.Email(
        user_id=user_id,
        context=request.context,
        tone=request.tone,
        key_points=request.key_points,
        result_json=email_data
    )
    db.add(new_email)
    db.commit()
    
    return email_data

@app.get("/history")
def get_history(user_name: Optional[str] = None, db: Session = Depends(database.get_db)):
    # If we had a name field in Email, we'd filter by it. 
    # For now, we'll return the last 20 emails as a "Global Session History" for the hackathon
    return db.query(models.Email).order_by(models.Email.timestamp.desc()).limit(20).all()

@app.get("/insights")
def get_insights(db: Session = Depends(database.get_db)):
    emails = db.query(models.Email).all()
    return generator.calculate_insights(emails)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
